package dev.aliska.bocchi.compat;
import dev.aliska.bocchi.BocchiMod;
import com.google.gson.JsonParser;
import com.mojang.serialization.JsonOps;
import mezz.jei.api.IModPlugin;
import mezz.jei.api.JeiPlugin;
import mezz.jei.api.constants.VanillaTypes;
import mezz.jei.api.constants.RecipeTypes;
import mezz.jei.api.registration.IRecipeRegistration;
import mezz.jei.api.registration.IExtraIngredientRegistration;
import mezz.jei.api.runtime.IJeiRuntime;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1799;
import net.minecraft.class_1860;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3955;
import net.minecraft.class_638;
import net.minecraft.class_8786;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.stream.Stream;
@JeiPlugin
@Environment(EnvType.CLIENT)
public class BtrJeiPlugin implements IModPlugin {
 @Override public class_2960 getPluginUid() { return BocchiMod.id("jei"); }
 @Override public void registerExtraIngredients(IExtraIngredientRegistration registration) {
  registration.addExtraIngredients(VanillaTypes.ITEM_STACK,BocchiMod.ITEMS.stream().map(class_1799::new).toList());
 }
 @Override public void registerRecipes(IRecipeRegistration registration) {
  var world=class_310.method_1551().field_1687;
  if(world==null) return;
  var recipes=new ArrayList<class_8786<class_3955>>();
  var root=FabricLoader.getInstance().getModContainer("bocchi").orElseThrow().findPath("data/bocchi/recipe").orElseThrow();
  try(var files=Files.list(root)) {
   for(var path:files.filter(p->p.toString().endsWith(".json")).toList()) {
    var result=class_1860.field_47319.parse(world.method_30349().method_57093(JsonOps.INSTANCE),JsonParser.parseString(Files.readString(path))).getOrThrow();
    if(result instanceof class_3955 crafting) recipes.add(new class_8786<>(BocchiMod.id(path.getFileName().toString().replace(".json","")),crafting));
   }
  } catch(Exception e) { throw new IllegalStateException("Cannot register BTR World JEI recipes",e); }
  // Local definitions retain real item identities instead of server-side paper substitutes.
  registration.addRecipes(RecipeTypes.CRAFTING,recipes);
 }
 @Override public void onRuntimeAvailable(IJeiRuntime runtime) {
  var hidden=new ArrayList<class_1799>();
  BocchiMod.MODELS.values().forEach(item->hidden.add(new class_1799(item)));
  hidden.add(new class_1799(BocchiMod.BOX_MODEL));
  runtime.getIngredientManager().removeIngredientsAtRuntime(VanillaTypes.ITEM_STACK,hidden);
 }
}
