package dev.aliska.bocchi;
import eu.pb4.polymer.core.api.entity.PolymerEntity;
import java.util.ArrayList;
import dev.aliska.bocchi.mixin.ItemDisplayAccessor;
import dev.aliska.bocchi.mixin.DisplayAccessor;
import org.joml.Vector3f;
import org.joml.Quaternionf;
import net.minecraft.class_1266;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1315;
import net.minecraft.class_1338;
import net.minecraft.class_1347;
import net.minecraft.class_1350;
import net.minecraft.class_1352;
import net.minecraft.class_1361;
import net.minecraft.class_1376;
import net.minecraft.class_1386;
import net.minecraft.class_1394;
import net.minecraft.class_1493;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1928;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3730;
import net.minecraft.class_4590;
import net.minecraft.class_5425;
import net.minecraft.class_811;
import net.minecraft.class_8113;
import net.minecraft.entity.*;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.passive.*;
import net.minecraft.entity.effect.*;
import net.minecraft.item.*;
import net.minecraft.util.*;
import net.minecraft.world.*;

public class CompanionEntity extends class_1493 implements PolymerEntity {
 private int hidingTicks, grassTicks, happyTicks, panicTicks;
 private java.util.UUID bandLeader;
 private float visualMountOffset = Float.NaN;
 public CompanionEntity(class_1299<? extends class_1493> type, class_1937 world) {
  super(type, world);
  method_5648(true); method_5803(true); method_5971();
 }
 public CharacterKind kind() { return BocchiMod.KINDS.getOrDefault(method_5864(), CharacterKind.BOCCHI); }
 public boolean plush() { return BocchiMod.PLUSH_TYPES.contains(method_5864()); }
 @Override protected void method_5959() {
  field_6201.method_6277(0,new class_1347(this));
  field_6201.method_6277(1,new class_1386(this));
  field_6201.method_6277(2,new class_1338<class_1588>(this,class_1588.class,7,1.15,1.4) {
   @Override public boolean method_6264() { return kind()==CharacterKind.BOCCHI && panicTicks>0 && !method_24345() && super.method_6264(); }
   @Override public boolean method_6266() { return panicTicks>0 && !method_24345() && super.method_6266(); }
  });
  field_6201.method_6277(3,new FollowBandGoal());
  field_6201.method_6277(3,new class_1350(this,1.1,3.0F,1.5F));
  field_6201.method_6277(4,new class_1394(this,0.65));
  field_6201.method_6277(5,new class_1361(this,class_1657.class,6.0F));
  field_6201.method_6277(6,new class_1376(this));
 }
 @Override public class_1299<?> getPolymerEntityType(class_3222 player) { return class_1299.field_6055; }
 @Override public class_1269 method_5992(class_1657 player, class_1268 hand) {
  class_1799 held = player.method_5998(hand);
  if (method_37908().field_9236) return class_1269.field_5812;
  if (!method_6181() && held.method_31574(kind().treat)) {
   happyTicks=100; consume(player,held); method_6170(player); method_24346(false); method_6025(method_6063());
   method_37908().method_8421(this,(byte)7);
   player.method_7353(class_2561.method_43470(kind().name+": теперь пойдём вместе! 💛"),true);
   return class_1269.field_5812;
  }
  if (method_6171(player)) {
   if (kind()==CharacterKind.RYO && held.method_31574(class_1802.field_8687)) {
    happyTicks=60; consume(player,held);
    class_1792 item = BocchiMod.FIGURINES.get(CharacterKind.values()[field_5974.method_43048(4)]);
    if(!player.method_7270(new class_1799(item))) player.method_7328(new class_1799(item),false);
    player.method_7353(class_2561.method_43470("Рё: фигурка за изумруд. Никаких возвратов."),true);
    return class_1269.field_5812;
   }
   if (held.method_31574(kind().treat)) { happyTicks=80; consume(player,held); method_6025(6); method_37908().method_8421(this,(byte)7); return class_1269.field_5812; }
   if (held.method_7960()) {
    method_24346(!method_24345()); field_6189.method_6340();
    player.method_7353(class_2561.method_43470(kind().name+(method_24345()?": подожду здесь.":": иду за Алиской!")),true);
    return class_1269.field_5812;
   }
  }
  // Keep name tags and leads, but prevent vanilla bone taming or another player's commands.
  if (held.method_31574(class_1802.field_8448) || held.method_31574(class_1802.field_8719)) return super.method_5992(player,hand);
  return class_1269.field_5811;
 }
 private void consume(class_1657 player, class_1799 stack) { if(!player.method_31549().field_7477) stack.method_7934(1); }
 @Override public boolean method_6481(class_1799 stack) { return false; }
 @Override public class_1493 method_5613(class_3218 world, class_1296 entity) { return null; }
 @Override protected class_3414 method_5994() { return null; }
 @Override public void method_5773() {
  super.method_5773();
  if (!(method_37908() instanceof class_3218 world) || !method_5805()) return;
  method_5648(true);
  if(happyTicks>0) happyTicks--;
  if(panicTicks>0 && --panicTicks==0) hidingTicks=60;
  if(hidingTicks>0) { hidingTicks--; field_6189.method_6340(); }
  if(grassTicks>0) { grassTicks--; field_6189.method_6340(); }
  if(kind()==CharacterKind.BOCCHI && field_6012%20==0) {
   boolean danger=!world.method_8390(class_1588.class,method_5829().method_1014(5),class_1297::method_5805).isEmpty();
   if(danger && !method_24345() && panicTicks==0 && hidingTicks==0) panicTicks=60;
  }
  if(kind()==CharacterKind.RYO && !method_24345() && hidingTicks==0 && field_6012%20==0) eatGrass(world);
  if(kind()==CharacterKind.KITA && field_6012%10==0) {
   world.method_14199(class_2398.field_11207,method_23317(),method_23318()+0.7,method_23321(),2,0.3,0.2,0.3,0.01);
   if(method_6181() && method_35057()!=null && method_5739(method_35057())<8 && field_6012%40==0)
    method_35057().method_6092(new class_1293(class_1294.field_5925,240,0,true,false,true));
  }
  if(kind()==CharacterKind.NIJIKA && method_6181() && !method_24345() && field_6012%200==0 && method_35057()!=null && method_5739(method_35057())<8) {
   method_35057().method_6092(new class_1293(class_1294.field_5917,100,0,true,false,true));
   world.method_14199(class_2398.field_11224,method_23317(),method_23318()+0.9,method_23321(),1,0,0,0,0);
   world.method_8396(null,method_24515(),class_3417.field_14708.comp_349(),net.minecraft.class_3419.field_15254,0.2F,1.2F);
  }
  if(kind()==CharacterKind.NIJIKA && bandLeader!=null && !method_24345() && field_6012%40==0) {
   class_1297 leader=world.method_14190(bandLeader);
   if(leader instanceof CompanionEntity bocchi && bocchi.kind()==CharacterKind.BOCCHI && bocchi.panicTicks>0 && method_5858(bocchi)<36) {
    bocchi.panicTicks=Math.max(1,bocchi.panicTicks-10);
    world.method_14199(class_2398.field_11224,method_23317(),method_23318()+.9,method_23321(),1,0,0,0,0);
    world.method_8396(null,method_24515(),class_3417.field_14708.comp_349(),net.minecraft.class_3419.field_15254,.15F,1.4F);
   }
  }
  updateVisual(world);
 }
 private void eatGrass(class_3218 world) {
  class_2338 pos=method_24515();
  if(world.method_8320(pos).method_27852(class_2246.field_10479)) {
   if(world.method_8450().method_8355(class_1928.field_19388)) world.method_8651(pos,false,this);
   grassTicks=30; method_6025(1);
   world.method_14199(class_2398.field_11211,method_23317(),method_23318()+0.4,method_23321(),3,0.2,0.1,0.2,0);
  } else if(world.method_8320(pos.method_10074()).method_27852(class_2246.field_10219) && field_6012%100==0) {
   if(world.method_8450().method_8355(class_1928.field_19388)) world.method_8501(pos.method_10074(),class_2246.field_10566.method_9564());
   grassTicks=30; method_6025(1);
  }
 }
 private void updateVisual(class_3218 world) {
  class_8113.class_8122 display=null;
  for(class_1297 passenger:method_5685()) if(passenger instanceof class_8113.class_8122 item) { display=item; break; }
  if(display==null) {
   visualMountOffset=Float.NaN;
   display=new class_8113.class_8122(class_1299.field_42456,world);
   display.method_33574(method_19538());
   display.method_5780("bocchi_companion_visual");
   ((ItemDisplayAccessor)display).bocchi$setMode(class_811.field_4315);
   world.method_8649(display); display.method_5873(this,true);
  }
  // The client sees a vanilla wolf, whose mount attachment differs from this custom type.
  // Compensate its mount height in tracked display data (server positioning alone cannot do this).
  if(Float.isNaN(visualMountOffset)) {
   class_1493 vanillaWolf=new class_1493(class_1299.field_6055,world);
   visualMountOffset=(float)(vanillaWolf.method_52538(display).field_1351-vanillaWolf.method_23318());
   ((DisplayAccessor)display).bocchi$setTransformation(new class_4590(
   new Vector3f(0,-visualMountOffset,0),new Quaternionf(),new Vector3f(1,1,1),new Quaternionf()));
  }
  String mood=field_6235>0?"surprised":happyTicks>0?"happy":(grassTicks>0 || panicTicks>0)?"squint":method_24345()?"sleepy":"";
  String name=kind().id+(plush()?"_plush":"_chibi")+(mood.isEmpty()?"":"_"+mood);
  class_1792 visual=hidingTicks>0?BocchiMod.BOX_MODEL:BocchiMod.MODELS.get(name);
  if (!((ItemDisplayAccessor)display).bocchi$getItemStack().method_31574(visual)) ((ItemDisplayAccessor)display).bocchi$setItemStack(new class_1799(visual));
  display.method_36456(method_36454()); display.method_36457(0);
  display.method_5834(kind()==CharacterKind.KITA);
 }
 @Override protected void method_5865(class_1297 passenger, class_1297.class_4738 updater) {
  if(passenger instanceof class_8113.class_8122) updater.accept(passenger,method_23317(),method_23318(),method_23321());
  else super.method_5865(passenger,updater);
 }
 // Natural encounters are a band; item summons still create only the requested girl.
 @Override public class_1315 method_5943(class_5425 access, class_1266 difficulty, class_3730 reason, class_1315 data) {
  class_1315 result=super.method_5943(access,difficulty,reason,data);
  if(reason==class_3730.field_16459 && access instanceof class_3218 world) {
   var members=new java.util.ArrayList<CompanionEntity>(); members.add(this);
   int offset=0;
   for(CharacterKind wanted:CharacterKind.values()) {
    if(wanted==kind()) continue;
    class_1299<?> type=BocchiMod.KINDS.keySet().stream().filter(t->BocchiMod.KINDS.get(t)==wanted && BocchiMod.PLUSH_TYPES.contains(t)==plush()).findFirst().orElseThrow();
    CompanionEntity friend=(CompanionEntity)type.method_5883(world);
    if(friend==null) continue;
    boolean placed=false;
    int[][] spots={{2,0},{-2,0},{0,2},{0,-2},{2,2},{-2,-2}};
    for(int i=0;i<spots.length && !placed;i++) {
     int[] spot=spots[(i+offset)%spots.length];
     for(int dy:new int[]{0,1,-1}) {
      class_2338 pos=method_24515().method_10069(spot[0],dy,spot[1]);
      friend.method_5808(pos.method_10263()+.5,pos.method_10264(),pos.method_10260()+.5,method_36454(),0);
      if(world.method_8320(pos.method_10074()).method_26212(world,pos.method_10074()) && world.method_17892(friend) && !world.method_22345(friend.method_5829())) {
       if(world.method_8649(friend)) { members.add(friend); placed=true; } break;
      }
     }
    }
    offset++;
   }
   CompanionEntity leader=members.stream().filter(m->m.kind()==CharacterKind.BOCCHI).findFirst().orElse(this);
   for(CompanionEntity member:members) member.bandLeader=leader.method_5667();
  }
  return result;
 }
 private final class FollowBandGoal extends class_1352 {
  private CompanionEntity leader;
  private int repath;
  FollowBandGoal() { method_6265(java.util.EnumSet.of(class_4134.field_18405)); }
  private CompanionEntity findLeader() {
   if(bandLeader==null || bandLeader.equals(method_5667()) || !(method_37908() instanceof class_3218 world)) return null;
   class_1297 entity=world.method_14190(bandLeader);
   return entity instanceof CompanionEntity girl && girl.method_5805()?girl:null;
  }
  @Override public boolean method_6264() {
   leader=findLeader();
   return !method_6181() && !method_24345() && grassTicks==0 && hidingTicks==0 && leader!=null && method_5858(leader)>6.25 && method_5858(leader)<1024;
  }
  @Override public boolean method_6266() {
   return !method_6181() && !method_24345() && grassTicks==0 && leader!=null && leader.method_5805() && method_5858(leader)>3 && method_5858(leader)<1024;
  }
  @Override public void method_6269() { repath=0; }
  @Override public void method_6268() {
   if(--repath<=0) { repath=10; field_6189.method_6335(leader,leader.panicTicks>0?1.25:.9); }
   method_5988().method_6226(leader,20,20);
  }
  @Override public void method_6270() { field_6189.method_6340(); leader=null; }
 }
 @Override public void method_5650(class_5529 reason) {
  // Passengers remain saved with their parent on chunk unload; discard only on actual destruction.
  if(reason.method_31486()) for(class_1297 passenger:method_5685()) passenger.method_31472();
  super.method_5650(reason);
 }
 @Override public void method_5652(class_2487 nbt) { super.method_5652(nbt); nbt.method_10569("BocchiHiding",hidingTicks); nbt.method_10569("BocchiPanic",panicTicks); if(bandLeader!=null) nbt.method_25927("BocchiBandLeader",bandLeader); }
 @Override public void method_5749(class_2487 nbt) { super.method_5749(nbt); hidingTicks=nbt.method_10550("BocchiHiding"); panicTicks=nbt.method_10550("BocchiPanic"); bandLeader=nbt.method_25928("BocchiBandLeader")?nbt.method_25926("BocchiBandLeader"):null; method_5648(true); method_5803(true); }
}
