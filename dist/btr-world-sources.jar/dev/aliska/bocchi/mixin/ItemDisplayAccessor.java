package dev.aliska.bocchi.mixin;
import net.minecraft.class_1799;
import net.minecraft.class_811;
import net.minecraft.class_8113;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;
@Mixin(class_8113.class_8122.class)
public interface ItemDisplayAccessor {
 @Invoker("getItemStack") class_1799 bocchi$getItemStack();
 @Invoker("setItemStack") void bocchi$setItemStack(class_1799 stack);
 @Invoker("setTransformationMode") void bocchi$setMode(class_811 mode);
}
