package dev.aliska.bocchi.mixin;
import net.minecraft.class_4590;
import net.minecraft.class_8113;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;
@Mixin(class_8113.class)
public interface DisplayAccessor {
 @Invoker("setTransformation") void bocchi$setTransformation(class_4590 transformation);
}
