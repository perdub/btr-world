package dev.aliska.bocchi;
import eu.pb4.polymer.core.api.item.PolymerItem;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3222;
import net.minecraft.class_5151;
import net.minecraft.class_9282;
import net.minecraft.class_9285;
import net.minecraft.class_9334;
import net.minecraft.item.*;
import net.minecraft.util.*;
/** Cosmetic leather rendering with no armour attributes or special buffs. */
public final class CostumeItem extends class_1792 implements PolymerItem,class_5151 {
 private final class_1304 slot;private final class_1792 appearance;
 public CostumeItem(class_1304 slot,class_1792 appearance) {
  super(new class_1792.class_1793().method_7889(1).method_57349(class_9334.field_49644,new class_9282(0xefa1c4,false)).method_57349(class_9334.field_49636,class_9285.field_49326));
  this.slot=slot;this.appearance=appearance;
 }
 @Override public class_1304 method_7685() { return slot; }
 @Override public class_1792 getPolymerItem(class_1799 stack,class_3222 player) { return appearance; }
 @Override public class_1271<class_1799> method_7836(class_1937 world,class_1657 player,class_1268 hand) { return method_48576(this,world,player,hand); }
}
