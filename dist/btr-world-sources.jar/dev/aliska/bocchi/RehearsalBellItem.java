package dev.aliska.bocchi;
import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.item.*;
import net.minecraft.util.*;
import net.minecraft.sound.*;
public final class RehearsalBellItem extends ModelItem {
 public RehearsalBellItem() { super("rehearsal_bell",new class_1792.class_1793().method_7889(1)); }
 @Override public class_1271<class_1799> method_7836(class_1937 world,class_1657 player,class_1268 hand) {
  if(!world.field_9236 && !player.method_7357().method_7904(this)) {
   var girls=world.method_8390(CompanionEntity.class,player.method_5829().method_1014(24),girl->girl.method_5805()&&girl.method_6171(player)&&girl.method_5858(player)<=576);
   for(var girl:girls) girl.recall();
   if(!girls.isEmpty()) BtrAdvancements.grant(player,"rehearsal");
   world.method_8396(null,player.method_24515(),class_3417.field_17265,class_3419.field_15248,.5F,1.3F);
   player.method_7357().method_7906(this,60);
  }
  return class_1271.method_22427(player.method_5998(hand));
 }
}
