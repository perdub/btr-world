package dev.aliska.bocchi;
import eu.pb4.polymer.blocks.api.*;
import net.minecraft.class_2246;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
final class BlockVisuals {
 static class_2680 allocate(String id, PolymerBlockModel model, boolean solid) {
  var primary=solid?BlockModelType.FULL_BLOCK:BlockModelType.TRIPWIRE_BLOCK_FLAT;
  class_2680 state=PolymerBlockResourceUtils.requestBlock(primary,model);
  if(state==null && !solid) state=PolymerBlockResourceUtils.requestBlock(BlockModelType.TRIPWIRE_BLOCK,model);
  if(state!=null) return state;
  org.slf4j.LoggerFactory.getLogger("bocchi").warn("No Polymer model states available for bocchi:{} ({}). Using safe vanilla fallback; custom model unavailable. Other Polymer mods share this pool.",id,primary);
  return solid?class_2246.field_10446.method_9564():class_2246.field_10124.method_9564();
 }
 static void exhaustForTest() {
  if (!Boolean.getBoolean("bocchi.testExhaustedBlockStates")) return;
  for (var type : new BlockModelType[]{BlockModelType.FULL_BLOCK,BlockModelType.TRIPWIRE_BLOCK_FLAT,BlockModelType.TRIPWIRE_BLOCK}) {
   int count=PolymerBlockResourceUtils.getBlocksLeft(type);
   for(int i=0;i<count;i++) PolymerBlockResourceUtils.requestBlock(type,PolymerBlockModel.of(class_2960.method_60655("bocchi","block/exhaustion_probe_"+type.name().toLowerCase()+"_"+i)));
  }
 }
}
