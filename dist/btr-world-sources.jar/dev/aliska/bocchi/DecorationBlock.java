package dev.aliska.bocchi;
import eu.pb4.polymer.blocks.api.*;
import net.minecraft.block.*;
import net.minecraft.class_1269;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1657;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.entity.effect.*;
import net.minecraft.util.*;
import net.minecraft.util.math.*;
import net.minecraft.util.shape.*;
import net.minecraft.world.*;
public class DecorationBlock extends class_2248 implements PolymerTexturedBlock {
 private final class_2680 visual;
 private final String id;
 public DecorationBlock(String id) {
  super(class_2251.method_9637().method_9632(0.7F).method_22488().method_9634().method_9626(net.minecraft.class_2498.field_11547));
  this.id=id;
  visual=BlockVisuals.allocate(id,PolymerBlockModel.of(class_2960.method_60655("bocchi","block/"+id)),false);
 }
 @Override public class_2680 getPolymerBlockState(class_2680 state) { return visual!=null?visual:class_2246.field_10124.method_9564(); }
 @Override protected class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
  return class_2248.method_9541(2,0,2,14,id.endsWith("figurine")?13:12,14);
 }
 @Override protected class_265 method_9549(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
  return class_259.method_1073();
 }
 @Override protected class_1269 method_55766(class_2680 state,class_1937 world,class_2338 pos,class_1657 player,class_3965 hit) {
  if(world.field_9236) return class_1269.field_5812;
  if(id.equals("bocchi_box")) {
   if (!BoxSeats.sit((class_3218) world, pos, player)) return class_1269.field_5811;
   if (!player.method_7357().method_7904(method_8389())) {
   player.method_6092(new class_1293(class_1294.field_5905,200,0,false,false,true));
   player.method_7357().method_7906(method_8389(),400);
   }
   return class_1269.field_5812;
  }
  if(id.equals("drum_kit")) {
   player.method_6092(new class_1293(class_1294.field_5917,200,0,true,false,true));
   world.method_8396(null,pos,net.minecraft.class_3417.field_14708.comp_349(),net.minecraft.class_3419.field_15245,0.6F,1);
   return class_1269.field_5812;
  }
  return class_1269.field_5811;
 }
}
