package dev.aliska.bocchi;
import net.minecraft.class_1657;
import net.minecraft.class_3222;
import net.minecraft.class_8779;
public final class BtrAdvancements {
 public static void grant(class_1657 player,String id) { grant(player,id,"done"); }
 public static void grant(class_1657 player,String id,String criterion) {
  if(player instanceof class_3222 serverPlayer) {
   var root=serverPlayer.method_5682().method_3851().method_12896(BocchiMod.id("root"));
   if(root!=null) serverPlayer.method_14236().method_12878(root,"done");
   var entry=serverPlayer.method_5682().method_3851().method_12896(BocchiMod.id(id));
   if(entry!=null) serverPlayer.method_14236().method_12878(entry,criterion);
  }
 }
}
