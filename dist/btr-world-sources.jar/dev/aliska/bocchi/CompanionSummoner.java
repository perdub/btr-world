package dev.aliska.bocchi;
import net.minecraft.class_1269;
import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_1838;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.item.*;
public class CompanionSummoner extends ModelItem {
 private final class_1299<CompanionEntity> type;
 public CompanionSummoner(String id, class_1299<CompanionEntity> type) { super(id,new class_1792.class_1793()); this.type=type; }
 @Override public class_1269 method_7884(class_1838 context) {
  if(!(context.method_8045() instanceof class_3218 world)) return class_1269.field_5812;
  class_2338 pos=context.method_8037().method_10093(context.method_8038());
  CompanionEntity entity=type.method_5883(world);
  if(entity==null) return class_1269.field_5814;
  entity.method_5808(pos.method_10263()+0.5,pos.method_10264(),pos.method_10260()+0.5,context.method_8044()+180,0);
  if(!world.method_8587(entity,entity.method_5829())) return class_1269.field_5814;
  entity.method_5665(class_2561.method_43470(entity.kind().name+(entity.plush()?" · тсум":" · чиби")));
  if(!world.method_8649(entity)) return class_1269.field_5814;
  if(context.method_8036()!=null && !context.method_8036().method_31549().field_7477) context.method_8041().method_7934(1);
  return class_1269.field_5812;
 }
}
