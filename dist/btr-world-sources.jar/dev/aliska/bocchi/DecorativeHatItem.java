package dev.aliska.bocchi;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_5151;
import net.minecraft.item.*;
import net.minecraft.util.*;
public final class DecorativeHatItem extends ModelItem implements class_5151 {
 public DecorativeHatItem(String model) { super(model,new class_1792.class_1793().method_7889(1)); }
 @Override public class_1304 method_7685() { return class_1304.field_6169; }
 @Override public class_1271<class_1799> method_7836(class_1937 world,class_1657 player,class_1268 hand) { return method_48576(this,world,player,hand); }
}
