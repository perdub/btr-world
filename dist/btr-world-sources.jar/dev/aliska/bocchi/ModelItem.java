package dev.aliska.bocchi;
import eu.pb4.polymer.core.api.item.PolymerItem;
import eu.pb4.polymer.resourcepack.api.PolymerResourcePackUtils;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.item.*;
public class ModelItem extends class_1792 implements PolymerItem {
 private final int model;
 public ModelItem(String id, class_1793 settings) {
  super(settings);
  model = PolymerResourcePackUtils.requestModel(class_1802.field_8407, class_2960.method_60655("bocchi", "item/"+id)).value();
 }
 @Override public class_1792 getPolymerItem(class_1799 stack, class_3222 player) { return class_1802.field_8407; }
 @Override public int getPolymerCustomModelData(class_1799 stack, class_3222 player) { return model; }
}
