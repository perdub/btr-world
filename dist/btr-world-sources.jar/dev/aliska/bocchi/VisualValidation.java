package dev.aliska.bocchi;
import dev.aliska.bocchi.mixin.DisplayAccessor;
import dev.aliska.bocchi.mixin.ItemDisplayAccessor;
import eu.pb4.polymer.common.api.PolymerCommonUtils;
import java.nio.file.Path;
import java.util.Map.Entry;
import net.fabricmc.loader.api.ModContainer;
import net.minecraft.class_1299;
import net.minecraft.class_1493;
import net.minecraft.class_1531;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3499;
import net.minecraft.class_4590;
import net.minecraft.class_811;
import net.minecraft.class_8113;
import net.minecraft.class_8113.class_8122;
import org.joml.Vector3f;
import org.joml.Quaternionf;
final class VisualValidation {
 static void run() {
  int checked=0;
  for(var entry:BocchiMod.BLOCKS.entrySet()) for(var state:entry.getValue().method_9595().method_11662()) {
   try {
    state.method_26200();
    if(((eu.pb4.polymer.blocks.api.PolymerTexturedBlock)entry.getValue()).getPolymerBlockState(state)==null) throw new IllegalStateException("Null client state");
    checked++;
   } catch(Exception error) { throw new IllegalStateException("Invalid Polymer mapping: bocchi:"+entry.getKey()+" "+state,error); }
  }
  org.slf4j.LoggerFactory.getLogger("bocchi").info("Validated {} Polymer block states including collision caches.",checked);
  if(BocchiMod.MODELS.size()!=40) throw new IllegalStateException("Expected 8 neutral and 32 expression models");
  var world=PolymerCommonUtils.getFakeWorld();
  var seat=new net.minecraft.class_1531(net.minecraft.class_1299.field_6131,world);
  BoxSeats.configure(seat);
  if (!seat.method_6912() || !seat.method_5767() || !seat.method_5740() || !seat.method_5655()) throw new IllegalStateException("Box seat configuration failed");
  var display=new class_8113.class_8122(class_1299.field_42456,world);
  var wolf=new class_1493(class_1299.field_6055,world);
  float offset=(float)(wolf.method_52538(display).field_1351-wolf.method_23318());
  if(offset<=0 || offset>2) throw new IllegalStateException("Unexpected wolf mount height "+offset);
  ((DisplayAccessor)display).bocchi$setTransformation(new class_4590(new Vector3f(0,-offset,0),new Quaternionf(),new Vector3f(1,1,1),new Quaternionf()));
  ((ItemDisplayAccessor)display).bocchi$setMode(class_811.field_4315);
  for(var item:BocchiMod.MODELS.values()) {
   ((ItemDisplayAccessor)display).bocchi$setItemStack(new class_1799(item));
   if(!((ItemDisplayAccessor)display).bocchi$getItemStack().method_31574(item)) throw new IllegalStateException("Display expression swap failed");
  }
  var nbt=new class_2487();display.method_5647(nbt);
  float saved=nbt.method_10562("transformation").method_10554("translation",class_2520.field_33255).method_10604(1);
  if(Math.abs(offset+saved)>0.00001) throw new IllegalStateException("Mount correction is not synchronized/saved");
  var type=BocchiMod.KINDS.keySet().stream().filter(t->BocchiMod.KINDS.get(t)==CharacterKind.BOCCHI).findFirst().orElseThrow();
  var probe=(CompanionEntity)type.method_5883(world);
  var familyNbt=new class_2487();probe.method_5652(familyNbt);
  familyNbt.method_10539("BtrGenes",new int[]{1,0,3});familyNbt.method_10569("BtrGrowth",1200);familyNbt.method_10569("BtrBreedCooldown",4000);
  probe.method_5749(familyNbt);
  var savedFamily=new class_2487();probe.method_5652(savedFamily);
  if(!java.util.Arrays.equals(savedFamily.method_10561("BtrGenes"),new int[]{1,0,3}) || savedFamily.method_10550("BtrGrowth")!=1200 || savedFamily.method_10550("BtrBreedCooldown")!=4000) throw new IllegalStateException("Family data did not survive NBT round trip");
  try {
   var mod=net.fabricmc.loader.api.FabricLoader.getInstance().getModContainer("bocchi").orElseThrow();
   for(var kind:CharacterKind.values()) {
    var path=mod.findPath("data/bocchi/structure/statues/"+kind.id+".nbt").orElseThrow();
    var templateNbt=net.minecraft.class_2507.method_30613(path,net.minecraft.class_2505.method_53898());
    for(var tag:templateNbt.method_10554("palette",class_2520.field_33260)) {
     var name=net.minecraft.class_2960.method_60654(((class_2487)tag).method_10558("Name"));
     if(!net.minecraft.class_7923.field_41175.method_10250(name)) throw new IllegalStateException("Unknown statue block "+name);
    }
    var template=new net.minecraft.class_3499();
    template.method_15183(net.minecraft.class_7923.field_41175.method_46771(),templateNbt);
    if(template.method_15160().method_10264()!=18 || templateNbt.method_10554("blocks",class_2520.field_33260).size()<500) throw new IllegalStateException("Invalid statue template "+kind.id);
   }
  } catch(Exception e) { throw new IllegalStateException("Statue validation failed",e); }
  org.slf4j.LoggerFactory.getLogger("bocchi").info("Visual validation passed: 40 models, display invokers, mount correction {} blocks.",offset);
 }
}
