package dev.aliska.bocchi;
import dev.aliska.bocchi.mixin.DisplayAccessor;
import dev.aliska.bocchi.mixin.ItemDisplayAccessor;
import eu.pb4.polymer.common.api.PolymerCommonUtils;
import net.minecraft.class_1299;
import net.minecraft.class_1493;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_4590;
import net.minecraft.class_811;
import net.minecraft.class_8113;
import net.minecraft.class_8113.class_8122;
import org.joml.Vector3f;
import org.joml.Quaternionf;
final class VisualValidation {
 static void run() {
  if(BocchiMod.MODELS.size()!=40) throw new IllegalStateException("Expected 8 neutral and 32 expression models");
  var world=PolymerCommonUtils.getFakeWorld();
  var display=new class_8113.class_8122(class_1299.field_42456,world);
  var wolf=new class_1493(class_1299.field_6055,world);
  float offset=(float)(wolf.method_52538(display).field_1351-wolf.method_23318());
  if(offset<=0 || offset>2) throw new IllegalStateException("Unexpected wolf mount height "+offset);
  ((DisplayAccessor)display).bocchi$setTransformation(new class_4590(new Vector3f(0,-offset,0),new Quaternionf(),new Vector3f(1,1,1),new Quaternionf()));
  ((ItemDisplayAccessor)display).bocchi$setMode(class_811.field_4315);
  for(var item:BocchiMod.MODELS.values()) {
   ((ItemDisplayAccessor)display).bocchi$setItemStack(new class_1799(item));
   if(!((ItemDisplayAccessor)display).bocchi$getItemStack().method_31574(item)) throw new IllegalStateException("Display expression swap failed");
  }
  var nbt=new class_2487();display.method_5647(nbt);
  float saved=nbt.method_10562("transformation").method_10554("translation",class_2520.field_33255).method_10604(1);
  if(Math.abs(offset+saved)>0.00001) throw new IllegalStateException("Mount correction is not synchronized/saved");
  org.slf4j.LoggerFactory.getLogger("bocchi").info("Visual validation passed: 40 models, display invokers, mount correction {} blocks.",offset);
 }
}
