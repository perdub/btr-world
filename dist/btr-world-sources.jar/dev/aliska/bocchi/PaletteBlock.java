package dev.aliska.bocchi;
import eu.pb4.polymer.blocks.api.*;
import net.minecraft.block.*;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
public class PaletteBlock extends class_2248 implements PolymerTexturedBlock {
 private final class_2680 clientState;
 public PaletteBlock(String id, class_2251 settings) {
  super(settings);
  clientState = BlockVisuals.allocate(id, PolymerBlockModel.of(class_2960.method_60655("bocchi", "block/"+id)),true);
 }
 @Override public class_2680 getPolymerBlockState(class_2680 state) { return clientState!=null?clientState:class_2246.field_10446.method_9564(); }
}
