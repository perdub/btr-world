package dev.aliska.bocchi;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1297;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.item.*;
import net.minecraft.util.*;
import net.minecraft.sound.*;
public class GuitarItem extends ModelItem {
 public GuitarItem() { super("guitar",new class_1792.class_1793().method_7889(1)); }
 @Override public class_1271<class_1799> method_7836(class_1937 world,class_1657 player,class_1268 hand) {
  if(!world.field_9236 && !player.method_7357().method_7904(this)) {
   boolean hit=false;
   for(class_1588 mob:world.method_8390(class_1588.class,player.method_5829().method_1014(4),class_1297::method_5805)) {
    hit=true;
    class_243 direction=mob.method_19538().method_1020(player.method_19538()).method_1029();
    mob.method_5762(direction.field_1352*0.8,0.25,direction.field_1350*0.8); mob.field_6037=true;
   }
   if(hit) BtrAdvancements.grant(player,"power_chord");
   world.method_8396(null,player.method_24515(),class_3417.field_14903.comp_349(),class_3419.field_15248,0.8F,1.2F);
   ((class_3218)world).method_14199(class_2398.field_11224,player.method_23317(),player.method_23318()+1,player.method_23321(),8,1,0.2,1,0);
   player.method_7357().method_7906(this,100);
  }
  return class_1271.method_22427(player.method_5998(hand));
 }
}
