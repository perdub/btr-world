package dev.aliska.bocchi;

import java.util.EnumMap;
import eu.pb4.polymer.blocks.api.*;
import net.minecraft.block.*;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2753;
import net.minecraft.class_2960;
import net.minecraft.class_3726;
import net.minecraft.class_4538;
import net.minecraft.util.math.*;
import net.minecraft.util.shape.*;
import net.minecraft.world.*;

public final class WallDecorBlock extends class_2248 implements PolymerTexturedBlock {
 public static final class_2753 FACING=class_2741.field_12525;
 private final EnumMap<class_2350,class_2680> visuals=new EnumMap<>(class_2350.class);
 private final boolean ceiling;
 public WallDecorBlock(String id,int light,boolean ceiling) {
  super(class_2251.method_9637().method_9632(.3F).method_22488().method_9634().method_9631(state->light).method_9626(net.minecraft.class_2498.field_11547));
  this.ceiling=ceiling;
  method_9590(method_9595().method_11664().method_11657(FACING,class_2350.field_11043));
  for(class_2350 direction:class_2350.values()) {
   if(!ceiling && direction.method_10166().method_10178()) continue;
   int x=direction==class_2350.field_11033?90:direction==class_2350.field_11036?270:0;
   int y=switch(direction) {case field_11034->90;case field_11035->180;case field_11039->270;default->0;};
   visuals.put(direction,PolymerBlockResourceUtils.requestBlock(BlockModelType.TRIPWIRE_BLOCK_FLAT,PolymerBlockModel.of(class_2960.method_60655("bocchi","block/"+id),x,y)));
  }
 }
 @Override protected void method_9515(class_2689.class_2690<class_2248,class_2680> builder) { builder.method_11667(FACING); }
 @Override public class_2680 getPolymerBlockState(class_2680 state) { return visuals.getOrDefault(state.method_11654(FACING),visuals.get(class_2350.field_11043)); }
 @Override public class_2680 method_9605(class_1750 context) {
  class_2350 face=context.method_8038();
  if(!ceiling && face.method_10166().method_10178()) return null;
  return method_9564().method_11657(FACING,face);
 }
 @Override protected boolean method_9558(class_2680 state,class_4538 world,class_2338 pos) {
  class_2350 facing=state.method_11654(FACING);
  class_2338 support=pos.method_10093(facing.method_10153());
  return world.method_8320(support).method_26206(world,support,facing);
 }
 @Override protected class_2680 method_9559(class_2680 state,class_2350 direction,class_2680 neighbor,class_1936 world,class_2338 pos,class_2338 neighborPos) {
  return direction==state.method_11654(FACING).method_10153() && !state.method_26184(world,pos)?class_2246.field_10124.method_9564():state;
 }
 @Override protected class_265 method_9530(class_2680 state,class_1922 world,class_2338 pos,class_3726 context) {
  return switch(state.method_11654(FACING)) {
   case field_11043->class_2248.method_9541(0,0,14,16,16,16);
   case field_11035->class_2248.method_9541(0,0,0,16,16,2);
   case field_11034->class_2248.method_9541(0,0,0,2,16,16);
   case field_11039->class_2248.method_9541(14,0,0,16,16,16);
   case field_11033->class_2248.method_9541(0,14,0,16,16,16);
   case field_11036->class_2248.method_9541(0,0,0,16,2,16);
  };
 }
}
