package dev.aliska.bocchi;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.biome.v1.*;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import eu.pb4.polymer.core.api.entity.PolymerEntityUtils;
import eu.pb4.polymer.core.api.item.PolymerItemGroupUtils;
import eu.pb4.polymer.resourcepack.api.PolymerResourcePackUtils;
import net.minecraft.entity.*;
import net.minecraft.item.*;
import net.minecraft.block.*;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1493;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1972;
import net.minecraft.class_2170;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_4970;
import net.minecraft.class_7923;
import net.minecraft.registry.*;
import java.util.*;
public class BocchiMod implements ModInitializer {
 public static final Map<class_1299<?>,CharacterKind> KINDS=new HashMap<>();
 public static final Set<class_1299<?>> PLUSH_TYPES=new HashSet<>();
 public static final Map<String,class_1792> MODELS=new HashMap<>();
 public static final Map<CharacterKind,class_1792> FIGURINES=new EnumMap<>(CharacterKind.class);
 public static final Map<String,class_2248> BLOCKS=new LinkedHashMap<>();
 public static final List<class_1792> ITEMS=new ArrayList<>();
 public static class_1792 BOX_MODEL;
 public static class_2960 id(String path) { return class_2960.method_60655("bocchi",path); }
 public static <T extends class_1792> T item(String path,T item) { class_2378.method_10230(class_7923.field_41178,id(path),item); ITEMS.add(item); return item; }
 @Override public void onInitialize() {
  PolymerResourcePackUtils.addModAssets("bocchi");
  PolymerResourcePackUtils.markAsRequired();
  BOX_MODEL=class_2378.method_10230(class_7923.field_41178,id("hiding_box"),new ModelItem("hiding_box",new class_1792.class_1793()));
  for(CharacterKind kind:CharacterKind.values()) {
   for(String form:List.of("plush","chibi")) {
    String name=kind.id+"_"+form;
    MODELS.put(name,class_2378.method_10230(class_7923.field_41178,id(name+"_model"),new ModelItem(name,new class_1792.class_1793())));
    for(String mood:List.of("happy","sleepy","surprised","squint")) {
     String variant=name+"_"+mood;
     MODELS.put(variant,class_2378.method_10230(class_7923.field_41178,id(variant+"_model"),new ModelItem(variant,new class_1792.class_1793())));
    }
    class_1299<CompanionEntity> type=class_2378.method_10230(class_7923.field_41177,id(name),class_1299.class_1300.method_5903(CompanionEntity::new,class_1311.field_6294).method_17687(0.65F,0.75F).method_27299(8).method_5905(null));
    KINDS.put(type,kind); if(form.equals("plush")) PLUSH_TYPES.add(type);
    FabricDefaultAttributeRegistry.register(type,class_1493.method_26897());
    PolymerEntityUtils.registerType(type);
    item(name+"_summoner",new CompanionSummoner(name+"_summoner",type));
    BiomeModifications.addSpawn(BiomeSelectors.includeByKey(class_1972.field_9451,class_1972.field_9409,class_1972.field_34470),class_1311.field_6294,type,2,1,1);
   }
   for(String shade:List.of("light","base","dark")) for(String finish:List.of("matte","tile","lamp")) {
    String name=kind.id+"_"+shade+"_"+finish;
    PaletteBlock block=new PaletteBlock(name,class_4970.class_2251.method_9637().method_9632(1.5F).method_9631(state->finish.equals("lamp")?15:0));
    class_2378.method_10230(class_7923.field_41175,id(name),block); BLOCKS.put(name,block);
    item(name,new PaletteItem(name,block));
   }
   String name=kind.id+"_figurine";
   DecorationBlock block=new DecorationBlock(name); class_2378.method_10230(class_7923.field_41175,id(name),block); BLOCKS.put(name,block);
   FIGURINES.put(kind,item(name,new PaletteItem(name,block)));
  }
  for(String name:List.of("bocchi_box","amplifier","speaker","drum_kit","microphone","guitar_case","starry_sign")) {
   DecorationBlock block=new DecorationBlock(name); class_2378.method_10230(class_7923.field_41175,id(name),block); BLOCKS.put(name,block); item(name,new PaletteItem(name,block));
  }
  item("guitar",new GuitarItem());
  PolymerItemGroupUtils.registerPolymerItemGroup(id("little_stage"),PolymerItemGroupUtils.builder().method_47321(class_2561.method_43470("BTR World")).method_47320(()->new class_1799(FIGURINES.get(CharacterKind.NIJIKA))).method_47317((context,entries)->ITEMS.forEach(entries::method_45421)).method_47324());
  if (Boolean.getBoolean("bocchi.validateResources")) {
   VisualValidation.run();
   if (!PolymerItemGroupUtils.contains(id("little_stage")) || ITEMS.size() != 56) {
    throw new IllegalStateException("BTR World creative tab registration failed: " + ITEMS.size() + " player-facing entries");
   }
   org.slf4j.LoggerFactory.getLogger("bocchi").info("Creative tab BTR World registered with {} player-facing entries.", ITEMS.size());
   boolean built=PolymerResourcePackUtils.buildMain(java.nio.file.Path.of("polymer/bocchi-validation-pack.zip"));
   if(!built) throw new IllegalStateException("Bocchi resource pack validation failed");
   org.slf4j.LoggerFactory.getLogger("bocchi").info("Resource pack validation passed.");
  }
  org.slf4j.LoggerFactory.getLogger("bocchi").info("Little Stage registered: 8 companions, 47 blocks, 56 recipes.");
  CommandRegistrationCallback.EVENT.register((dispatcher,access,env)-> {
   dispatcher.register(class_2170.method_9247("bocchi").then(class_2170.method_9247("stage").requires(source->source.method_9259(2)).executes(context-> {
    var player=context.getSource().method_9207(); class_3218 world=player.method_51469();
    class_2338 origin=player.method_24515().method_10069(0,0,3);
    // Never replace existing builds. The entire footprint must be air before placing anything.
    for(int x=-3;x<=3;x++) for(int z=0;z<=4;z++) for(int y=0;y<=3;y++) if(!world.method_8320(origin.method_10069(x,y,z)).method_26215()) {
     context.getSource().method_9213(class_2561.method_43470("Нужно свободное место 7×4×5 перед игроком (по оси +Z).")); return 0;
    }
    for(int x=-3;x<=3;x++) for(int z=0;z<=4;z++) world.method_8501(origin.method_10069(x,0,z),BLOCKS.get("ryo_dark_matte").method_9564());
    for(int x=-3;x<=3;x++) world.method_8501(origin.method_10069(x,1,4),BLOCKS.get("nijika_base_lamp").method_9564());
    world.method_8501(origin.method_10069(-2,1,2),BLOCKS.get("speaker").method_9564());
    world.method_8501(origin.method_10069(2,1,2),BLOCKS.get("amplifier").method_9564());
    world.method_8501(origin.method_10069(0,1,3),BLOCKS.get("drum_kit").method_9564());
    world.method_8501(origin.method_10069(0,1,1),BLOCKS.get("microphone").method_9564());
    world.method_8501(origin.method_10069(1,1,3),BLOCKS.get("starry_sign").method_9564());
    int x=-2; for(CharacterKind kind:CharacterKind.values()) world.method_8501(origin.method_10069(x++,1,0),BLOCKS.get(kind.id+"_figurine").method_9564());
    context.getSource().method_9226(()->class_2561.method_43470("Маленькая сцена готова!"),false); return 1;
   })));
  });
 }
}
