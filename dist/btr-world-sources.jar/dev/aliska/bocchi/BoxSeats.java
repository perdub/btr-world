package dev.aliska.bocchi;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1531;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_3218;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;

/** Vanilla marker seats: no client mod is required. */
public final class BoxSeats {
 private static final String TAG = "btr_box_seat";
 private static final Map<class_1531, class_2338> SEATS = new HashMap<>();
 private BoxSeats() {}
 public static void initialize() {
  ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
   if (entity instanceof class_1531 stand && stand.method_5752().contains(TAG)) {
    SEATS.put(stand, class_2338.method_49637(stand.method_23317(), stand.method_23318(), stand.method_23321()));
   }
  });
  ServerTickEvents.END_WORLD_TICK.register(world -> SEATS.entrySet().removeIf(entry -> {
   class_1531 seat = entry.getKey();
   if (seat.method_37908() != world) return false;
   if (seat.method_31481()) return true;
   if (!seat.method_5782() || !world.method_8320(entry.getValue()).method_27852(BocchiMod.BLOCKS.get("bocchi_box"))) {
    seat.method_31472();
    return true;
   }
   return false;
  }));
  ServerLifecycleEvents.SERVER_STOPPED.register(server -> SEATS.clear());
 }
 public static boolean sit(class_3218 world, class_2338 pos, class_1657 player) {
  if (player.method_5715() || player.method_5765()) return false;
  for (var entry : SEATS.entrySet()) {
   if (entry.getKey().method_37908() == world && !entry.getKey().method_31481()
       && entry.getValue().equals(pos) && entry.getKey().method_5782()) return false;
  }
  class_1531 seat = new class_1531(world, pos.method_10263() + .5, pos.method_10264() + .1, pos.method_10260() + .5);
  configure(seat);
  seat.method_5814(pos.method_10263() + .5, pos.method_10264() + .1, pos.method_10260() + .5);
  seat.method_5780(TAG);
  if (!world.method_8649(seat)) return false;
  if (!player.method_5873(seat, true)) { seat.method_31472(); return false; }
  SEATS.put(seat, pos.method_10062());
  return true;
 }
 static void configure(class_1531 seat) {
  class_2487 flags = new class_2487();
  flags.method_10556("Marker", true);
  flags.method_10556("Invisible", true);
  flags.method_10556("NoGravity", true);
  flags.method_10556("Invulnerable", true);
  flags.method_10556("Silent", true);
  seat.method_5651(flags);
 }

}
