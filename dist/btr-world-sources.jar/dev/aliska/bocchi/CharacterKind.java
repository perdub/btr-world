package dev.aliska.bocchi;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
public enum CharacterKind {
 BOCCHI("bocchi", "Хитори", class_1802.field_8423),
 NIJIKA("nijika", "Нидзика", class_1802.field_17534),
 RYO("ryo", "Рё", class_1802.field_8861),
 KITA("kita", "Кита", class_1802.field_28659);
 public final String id, name;
 public final class_1792 treat;
 CharacterKind(String id, String name, class_1792 treat) { this.id=id; this.name=name; this.treat=treat; }
}
