package dev.aliska.bocchi;
import eu.pb4.polymer.core.api.item.PolymerBlockItem;
import eu.pb4.polymer.resourcepack.api.PolymerResourcePackUtils;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.item.*;
public class PaletteItem extends PolymerBlockItem {
 private final int model;
 public PaletteItem(String id, class_2248 block) {
  super(block, new class_1792.class_1793(), class_1802.field_8407);
  model = PolymerResourcePackUtils.requestModel(class_1802.field_8407, class_2960.method_60655("bocchi", "item/"+id)).value();
 }
 @Override public int getPolymerCustomModelData(class_1799 stack, class_3222 player) { return model; }
}
